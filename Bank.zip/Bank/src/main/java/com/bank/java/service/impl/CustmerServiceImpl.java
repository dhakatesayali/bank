package com.bank.java.service.impl;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bank.java.Dto.CustomerRequestDto;
import com.bank.java.Dto.CustomerResponseDto;
import com.bank.java.Dto.CustomerResponseProj;
import com.bank.java.entity.Customer;
import com.bank.java.exception.MyCustomizeedException;
import com.bank.java.repository.CustomerRepository;
import com.bank.java.service.CustomerService;

@Service
public class CustmerServiceImpl implements CustomerService {
	@Autowired
	CustomerRepository customerRepository;

	@Override
	public void saveCustomer(CustomerRequestDto customerRequestDto) {
		Customer customer = new Customer();
		BeanUtils.copyProperties(customerRequestDto, customer);
		customerRepository.save(customer);
	}

	@Override
	public List<CustomerResponseDto> getCustomers() {
		List<CustomerResponseDto> customerResponseDtoList = new ArrayList<CustomerResponseDto>();
		Iterator<Customer> it = customerRepository.findAll().iterator();

		while (it.hasNext()) {
			CustomerResponseDto customerResponseDto = new CustomerResponseDto();
			BeanUtils.copyProperties(it.next(), customerResponseDto);
			customerResponseDtoList.add(customerResponseDto);
		}
		return customerResponseDtoList;
	}

	@Override
	public void deleteCustomer(Integer customerId) {
		Customer customer= customerRepository.findById(customerId).get();
		if(customer==null) throw new MyCustomizeedException("No customer with the id: "+customerId);
		customer=new Customer();
		customer.setCustomerId(customerId);
		customerRepository.delete(customer);
	}

	@Override
	public List<CustomerResponseProj> getCustomerbyName(String customerName) {
		List<CustomerResponseProj> customerResponseProjList= customerRepository.findByCustomerNameContaining(customerName);
		if(customerResponseProjList.isEmpty()) throw new MyCustomizeedException("no customesrs with the name: "+customerName);
		return customerResponseProjList;
	}
	
}

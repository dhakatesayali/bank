package com.bank.java.entity;


import java.time.LocalDateTime;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import lombok.Data;

@Data
@Entity
public class Transaction {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer transactionId;
	private String transactionNumber;
	private Double amount;
	
	@ManyToOne
	@JoinColumn(name="accountId")
	private Account account;
	private String transactionType;
	private LocalDateTime date;
	
}

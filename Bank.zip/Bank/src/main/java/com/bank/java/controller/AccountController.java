package com.bank.java.controller;

import java.util.List;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.bank.java.Dto.AccountRequestDto;
import com.bank.java.Dto.AccountResponseDto;
import com.bank.java.Dto.AccountResponseProj;
import com.bank.java.service.AccountService;

@RestController
@Validated
public class AccountController {
	@Autowired
	AccountService accountService;
	
	@PostMapping("/accounts")
	public ResponseEntity<String> saveAccount(@Valid @RequestBody AccountRequestDto accountRequestDto){
		accountService.saveAccount(accountRequestDto);
		return new ResponseEntity<String>("account added succesfully",HttpStatus.ACCEPTED);
	}
	@GetMapping("/accounts")
	public ResponseEntity<List<AccountResponseDto>> getAccounts(){
		return new ResponseEntity<List<AccountResponseDto>>(accountService.getAccounts(),HttpStatus.ACCEPTED);
	}
	@GetMapping("/accounts/{customerId}")
	public ResponseEntity<List<AccountResponseProj>> getAccountsByCustomer(@NotNull(message="customer id cannot be null") @PathVariable Integer customerId){
		return new ResponseEntity<List<AccountResponseProj>>(accountService.getAccountsByCustomer(customerId),HttpStatus.ACCEPTED);
	}

}

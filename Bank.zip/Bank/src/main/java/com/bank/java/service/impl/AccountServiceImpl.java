package com.bank.java.service.impl;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bank.java.Dto.AccountRequestDto;
import com.bank.java.Dto.AccountResponseDto;
import com.bank.java.Dto.AccountResponseProj;
import com.bank.java.entity.Account;
import com.bank.java.entity.Customer;
import com.bank.java.exception.MyCustomizeedException;
import com.bank.java.repository.AccountRepository;
import com.bank.java.repository.CustomerRepository;
import com.bank.java.service.AccountService;

@Service
public class AccountServiceImpl implements AccountService {

	@Autowired
	AccountRepository accountRepository;
	@Autowired
	CustomerRepository customerRepository;

	@Override
	public void saveAccount(AccountRequestDto accountRequestDto) {
		Optional<Customer> opCustomer=customerRepository.findById(accountRequestDto.getCustomerId());
		
		if(opCustomer.isPresent()) {
			Customer customer=opCustomer.get();
			Account account = new Account();
			BeanUtils.copyProperties(accountRequestDto, account);
			account.setCustomer(customer);
			accountRepository.save(account);
		}
		else {
			throw new MyCustomizeedException("customer not present with id ");
		}
		
	}

	@Override
	public List<AccountResponseDto> getAccounts() {
		List<AccountResponseDto> accountResponseDtoList = new ArrayList<AccountResponseDto>();
		Iterator<Account> it = accountRepository.findAll().iterator();
		while (it.hasNext()) {
			AccountResponseDto accountResponseDto = new AccountResponseDto();
			BeanUtils.copyProperties(it.next(), accountResponseDto);
			accountResponseDtoList.add(accountResponseDto);
		}
		return accountResponseDtoList;
	}

	@Override
	public List<AccountResponseProj> getAccountsByCustomer(Integer customerId) {
		if(!customerRepository.findById(customerId).isPresent()) throw new MyCustomizeedException("No customer with the id: "+customerId);
		List<AccountResponseProj> accountResponseProjList=accountRepository.findByCustomerCustomerId(customerId);
		if(accountResponseProjList.isEmpty()) throw new MyCustomizeedException("No accounts with the customer id: "+customerId);
		return accountResponseProjList;
	}

}
